import { createContext } from "react"

export const BuyContext = createContext()