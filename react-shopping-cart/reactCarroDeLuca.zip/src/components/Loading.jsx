import "../styles/loading.css";

export const Loading = () => {

    return (
        <>
            <div className="loader"></div>
        </>
    )
}

export default Loading;